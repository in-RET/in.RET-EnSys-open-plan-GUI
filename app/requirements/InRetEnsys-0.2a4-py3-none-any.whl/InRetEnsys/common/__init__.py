##  @package common
#   Documentation for this package.
#
#   Collection of some tools for the InRetSys.Components.
#   The file 'config.py' contains the BaseClass of the configuration containers.
